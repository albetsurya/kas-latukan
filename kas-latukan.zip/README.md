# kas-latukan
