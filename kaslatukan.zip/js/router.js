// js/router.js

/**
 * Router untuk mengelola navigasi antar screen
 * Menggunakan hash-based routing
 */
class Router {
  constructor() {
    this.routes = {
      home: {
        path: "#home",
        title: "Beranda",
        screen: "screen-home",
        tab: "home",
      },
      history: {
        path: "#history",
        title: "Riwayat",
        screen: "screen-history",
        tab: "history",
      },
      recap: {
        path: "#recap",
        title: "Rekap",
        screen: "screen-recap",
        tab: "recap",
      },
      shodaqoh: {
        path: "#shodaqoh",
        title: "Shodaqoh",
        screen: "screen-shodaqoh",
        tab: "shodaqoh",
      },
      profile: {
        path: "#profile",
        title: "Profil",
        screen: "screen-profile",
        tab: "profile",
      },
    };

    this.currentRoute = "home";
    this.listeners = {};
    this.initialized = false;
    this._isNavigating = false;
  }

  /**
   * Inisialisasi router
   */
  init() {
    if (this.initialized) return;

    // Listener untuk hashchange
    window.addEventListener("hashchange", () => {
      if (!this._isNavigating) {
        this.handleRouteChange();
      }
    });

    // Listener untuk popstate (back/forward)
    window.addEventListener("popstate", () => {
      this.handleRouteChange();
    });

    this.initialized = true;

    // Handle initial route
    this.handleRouteChange();
  }

  /**
   * Handle perubahan route
   */
  handleRouteChange() {
    const hash = window.location.hash || "#home";
    const route = this.getRouteFromHash(hash);

    if (route) {
      this.navigateTo(route, false);
    } else {
      // Fallback ke home jika route tidak ditemukan
      this.navigateTo("home", false);
    }
  }

  /**
   * Dapatkan route dari hash
   */
  getRouteFromHash(hash) {
    const path = hash.split("?")[0]; // Hapus query params
    const routeKey = Object.keys(this.routes).find(
      (key) => this.routes[key].path === path,
    );
    return routeKey || null;
  }

  /**
   * Navigasi ke route tertentu
   */
  navigateTo(routeKey, updateHistory = true) {
    const route = this.routes[routeKey];
    if (!route) return;

    // Cegah navigasi ganda
    if (this._isNavigating && updateHistory) {
      return;
    }

    this._isNavigating = true;

    try {
      // Update state
      this.currentRoute = routeKey;

      // Update hash jika diperlukan
      if (updateHistory) {
        window.location.hash = route.path;
      }

      // Gunakan switchTab yang sudah ada
      if (typeof switchTab === "function") {
        switchTab(route.tab);
      }

      // Update title
      document.title = `Kas · ${route.title}`;

      // Update topbar title
      const screenTitle = document.getElementById("screenTitle");
      if (screenTitle) {
        screenTitle.textContent = route.title;
      }

      // Update nav buttons
      this.updateNavButtons(routeKey);

      // Trigger event
      this.trigger("routeChange", {
        route: routeKey,
        screen: route.screen,
        tab: route.tab,
      });
    } finally {
      this._isNavigating = false;
    }
  }

  /**
   * Update navigasi bottom
   */
  updateNavButtons(routeKey) {
    document.querySelectorAll(".nav-btn").forEach((btn) => {
      btn.classList.remove("active");
      if (btn.dataset.tab === routeKey) {
        btn.classList.add("active");
      }
    });
  }

  /**
   * Register event listener
   */
  on(event, callback) {
    if (!this.listeners[event]) {
      this.listeners[event] = [];
    }
    this.listeners[event].push(callback);
  }

  /**
   * Trigger event
   */
  trigger(event, data) {
    if (this.listeners[event]) {
      this.listeners[event].forEach((callback) => callback(data));
    }
  }

  /**
   * Dapatkan route saat ini
   */
  getCurrentRoute() {
    return this.currentRoute;
  }

  /**
   * Dapatkan data route
   */
  getRouteData(routeKey) {
    return this.routes[routeKey] || null;
  }

  /**
   * Navigasi ke halaman sebelumnya
   */
  goBack() {
    window.history.back();
  }

  /**
   * Set hash tanpa trigger navigasi
   */
  setHashWithoutNavigation(hash) {
    const currentHash = window.location.hash;
    if (currentHash !== hash) {
      window.history.pushState(null, "", hash);
    }
  }

  /**
   * Dapatkan query parameters dari hash
   */
  getQueryParams() {
    const hash = window.location.hash;
    const queryString = hash.includes("?") ? hash.split("?")[1] : "";
    const params = new URLSearchParams(queryString);
    const result = {};
    for (const [key, value] of params) {
      result[key] = value;
    }
    return result;
  }
}

// Export singleton instance
const router = new Router();

// Export ke global
window.router = router;
